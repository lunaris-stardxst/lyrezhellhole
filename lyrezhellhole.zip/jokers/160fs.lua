SMODS.Joker{ --exactly 160 fs
    name = "exactly 160 fs",
    key = "160fs",
    config = {
        extra = {
            mult = 160,
            j_joker = 0
        }
    },
    loc_txt = {
        ['name'] = 'exactly 160 fs',
        ['text'] = {
            [1] = '{X:mult,C:white}ffffffffffffffffffffffffffffffff{}',
            [2] = '{X:mult,C:white}ffffffffffffffffffffffffffffffff{}',
            [3] = '{X:mult,C:white}ffffffffffffffffffffffffffffffff{}',
            [4] = '{X:mult,C:white}ffffffffffffffffffffffffffffffff{}',
            [5] = '{X:mult,C:white}ffffffffffffffffffffffffffffffff{}'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    cost = 128,
    rarity = "lzh_coulibiac",
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
                local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local joker_card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_joker')
                            joker_card:add_to_deck()
                            G.jokers:emplace(joker_card)
                            G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        message = created_joker and localize('k_plus_joker') or nil,
                        colour = G.C.BLUE
                        }
                }
        end
    end
}