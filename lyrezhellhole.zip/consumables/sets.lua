SMODS.ConsumableType {
    key = 'what_the',
    shader = 'planet',
    primary_colour = HEX('461111'),
    secondary_colour = HEX('461111'),
    collection_rows = { 4, 5 },
    shop_rate = 0.1,
    cards = {
        ['c_lzh_soulhar'] = true,
        ['c_lzh_souleng'] = true,
        ['c_lzh_soulirs'] = true,
        ['c_lzh_soulofyou'] = true,
        ['c_lzh_soulbillionare'] = true
    },
    loc_txt = {
        name = "what the fucking",
        collection = "what the fucking Cards",
    }
}