SMODS.Joker{ --Pureprint
    name = "Pureprint",
    key = "pureprint",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Pureprint',
        ['text'] = {
            [1] = 'Copies {C:attention}every{} Joker'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    cost = 20,
    rarity = "lzh_pure",
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        local target_joker = nil
        
        target_joker = G.jokers.cards[1]
        if target_joker == card then
            target_joker = nil
        end
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end,

    calculate = function(self, card, context)
        local target_joker = nil
        
        target_joker = G.jokers.cards[2]
        if target_joker == card then
            target_joker = nil
        end
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end,

    calculate = function(self, card, context)
        local target_joker = nil
        
        target_joker = G.jokers.cards[3]
        if target_joker == card then
            target_joker = nil
        end
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end,

    calculate = function(self, card, context)
        local target_joker = nil
        
        target_joker = G.jokers.cards[4]
        if target_joker == card then
            target_joker = nil
        end
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end,

    calculate = function(self, card, context)
        local target_joker = nil
        
        target_joker = G.jokers.cards[5]
        if target_joker == card then
            target_joker = nil
        end
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end
}